package com.demo.gateway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * @author aleng
 * @version 1.0.0
 * @className MyGloablFilter
 * @description TODO
 * @createTime 2020年12月22日 02:57:00
 */
@Component
public class MyGloablFilter implements GlobalFilter, Ordered {
  @Override
  public Mono<Void> filter(final ServerWebExchange exchange, final GatewayFilterChain chain) {
      return chain.filter(exchange);
  }

  @Override
  public int getOrder() {
    return 0;
  }
}
