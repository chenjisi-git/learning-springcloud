package com.demo.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * GatewayApp
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 19:35
 */
@EnableDiscoveryClient
@SpringBootApplication
public class GatewayApp {
  public static void main(final String[] args) {
    SpringApplication.run(GatewayApp.class, args);
  }
}
