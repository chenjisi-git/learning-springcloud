package com.demo.registry.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * EurekaApp
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 14:29
 */
@EnableEurekaServer
@SpringBootApplication
public class EurekaAppDemo2 {
  public static void main(final String[] args) {
    SpringApplication.run(EurekaAppDemo2.class, args);
  }
}
