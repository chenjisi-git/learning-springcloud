package com.demo.service.user.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author cjs
 * @version 1.0.0
 * @className User
 * @description TODO
 * @createTime 2020年12月22日 01:22:00
 */
@Data
@Accessors(chain = true)
public class User {
    private Long id;
    private String email;
    @JSONField(serialize = false)
    private String password;
}
