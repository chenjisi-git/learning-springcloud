package com.demo.service.user.controller;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import com.demo.service.user.cache.UserCache;
import com.demo.service.user.entity.AuthCode;
import com.demo.service.user.entity.Token;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * UserDataController
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 20:31
 */
@RestController
@RequestMapping("/user")
public class UserDataController {

  /**
   * saveCode
   *
   * @param email the email
   * @param code the code
   * @return the boolean
   */
  @PostMapping("/data/{email}/{code}")
  public Boolean saveCode(@PathVariable final String email, @PathVariable final String code) {
    final Snowflake snowflake = IdUtil.createSnowflake(1, 1);
    UserCache.CODE_CACHE.put(
        code,
        new AuthCode()
            .setCode(code)
            .setCreateTime(new Date())
            .setEmail(email)
            .setId(snowflake.nextId()));
    return true;
  }
}
