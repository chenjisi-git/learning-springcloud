package com.demo.service.user.controller;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson.JSON;
import com.demo.service.user.cache.UserCache;
import com.demo.service.user.entity.AuthCode;
import com.demo.service.user.entity.Token;
import com.demo.service.user.entity.User;
import com.google.common.collect.ImmutableMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用户操作入口
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 18:13
 */
@RestController
@RequestMapping("/user")
public class UserController {

  /**
   * register
   *
   * @param email the email
   * @param password the password
   * @param code the code
   * @return the boolean
   */
  @PostMapping("/register/{email}/{password}/{code}")
  public Boolean register(
      @PathVariable final String email,
      @PathVariable final String password,
      @PathVariable final String code) {
    final AuthCode authCode = UserCache.CODE_CACHE.getIfPresent(code);
    if (null != authCode && email.equals(authCode.getEmail())) {
      final String token = IdUtil.fastUUID();
      UserCache.TOKEN_CACHE.put(token, new Token().setToken(token).setEmail(email));
      final Snowflake snowflake = IdUtil.createSnowflake(1, 1);
      UserCache.USER_MAP.put(
          email, new User().setId(snowflake.nextId()).setEmail(email).setPassword(password));
      return true;
    }
    return false;
  }

  /**
   * isRegistered
   *
   * @param email the email
   * @return the boolean
   */
  @PostMapping("/isRegistered/{email}")
  public Boolean isRegistered(@PathVariable final String email) {
    return UserCache.USER_MAP.get(email) != null;
  }

  /**
   * login
   *
   * @param email the email
   * @param password the password
   * @return the boolean
   */
  @PostMapping("/login/{email}/{password}")
  public String login(@PathVariable final String email, @PathVariable final String password) {
    final User user=UserCache.USER_MAP.get(email);
    if (null == user) {
      return JSON.toJSONString(ImmutableMap.of("code", -1, "msg", "用户名密码不正确"));
    } else {
      return JSON.toJSONString(user);
    }
  }

  /**
   * info
   *
   * @param token the token
   * @return the boolean
   */
  @PostMapping("/info/{token}")
  public String info(@PathVariable final String token) {
    final Token tokenEntity = UserCache.TOKEN_CACHE.getIfPresent(token);
    if (null == tokenEntity) {
      return JSON.toJSONString(ImmutableMap.of("code", -1, "msg", "token不正确"));
    } else {
      return JSON.toJSONString(tokenEntity);
    }
  }
}
