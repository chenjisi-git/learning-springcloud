package com.demo.service.user.service;

/**
 * IUserService
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 14:48
 */
public interface IUserService {}
