package com.demo.service.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * UserApp
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 14:48
 */
@EnableDiscoveryClient
@SpringBootApplication
public class UserApp {
  public static void main(final String[] args) {
    SpringApplication.run(UserApp.class, args);
  }
}
