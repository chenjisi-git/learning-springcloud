package com.demo.service.code.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * SendEmailService
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 18:01
 */
@FeignClient(name = "demo-service-email")
public interface SendEmailService {

  @PostMapping("/email/{email}/{code}")
  Boolean sendEmail(
      @PathVariable(value = "email") String email, @PathVariable(value = "code") String code);
}
