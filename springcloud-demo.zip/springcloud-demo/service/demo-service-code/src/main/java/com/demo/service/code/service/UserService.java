package com.demo.service.code.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * SendEmailService
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 18:01
 */
@FeignClient(name = "demo-service-user")
public interface UserService {

  @PostMapping("/user/data/{email}/{code}")
  Boolean saveUser(
      @PathVariable(value = "email") String email, @PathVariable(value = "code") String code);

  @PostMapping("/user/isRegistered/{email}")
  Boolean isRegistered(@PathVariable(value = "email") String email);
}
