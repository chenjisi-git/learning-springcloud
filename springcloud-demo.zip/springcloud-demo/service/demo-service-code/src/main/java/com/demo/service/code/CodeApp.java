package com.demo.service.code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * CodeApp
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 15:50
 */
@EnableDiscoveryClient
@SpringBootApplication
@EnableFeignClients
public class CodeApp {
  public static void main(final String[] args) {
    SpringApplication.run(CodeApp.class, args);
  }
}
