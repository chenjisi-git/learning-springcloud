package com.demo.service.email.controller;

import cn.hutool.extra.mail.MailUtil;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 发送邮件
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 15:47
 */
@RestController
@RequestMapping("/email")
public class SendEmailController {

  /**
   * sendEmail
   *
   * @param email the email
   * @param code the code
   * @return the boolean
   */
  @PostMapping("/{email}/{code}")
  public Boolean sendEmail(@PathVariable String email, @PathVariable String code) {
    MailUtil.send(email, "Verification Code", code, false);
    return true;
  }
}
