package com.demo.service.email;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * EmailApp
 *
 * @author aleng
 * @version 1.0
 * @since 2020/12/21 15:47
 */
@EnableDiscoveryClient
@SpringBootApplication
public class EmailApp {
  public static void main(final String[] args) {
    SpringApplication.run(EmailApp.class, args);
  }
}
