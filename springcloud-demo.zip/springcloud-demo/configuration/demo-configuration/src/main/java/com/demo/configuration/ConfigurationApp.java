package com.demo.configuration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * ConfigApp
 *
 * @author aleng
 * @version 1.0
 * @since 2020 /12/21 19:38
 */
@EnableDiscoveryClient
@SpringBootApplication
public class ConfigurationApp {
  /**
   * Main.
   *
   * @param args the args
   */
  public static void main(final String[] args) {
    SpringApplication.run(ConfigurationApp.class, args);
  }
}
